const pages = {
    home: (req, res) => {
      res.render("index");
    },
  };
  
  module.exports = pages;