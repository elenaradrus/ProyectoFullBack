document.getElementById('sing').addEventListener('click', () =>{
    mostrar(contenedorRegis)
})

function mostrar(id) {
    let test = document.getElementById('contenedorRegis');
    if (test.style.display == 'block') {
        test.style.display = 'none';
    } else {
        test.style.display = 'block'
    }
}


function btnGr(id) {
    let test = document.getElementById('contenedorRegis');
    if (test.style.display == 'inline') {
        test.style.display = 'block';
    } else {
        test.style.display = 'none'
    }
}